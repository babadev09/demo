package com.baburao.curd;

import database.DBHelper;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Delete extends Activity {
	
	EditText editTextDelete;
	Button btnDelete;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_delete);
		
		editTextDelete=(EditText)findViewById(R.id.editText_delete);
		btnDelete=(Button)findViewById(R.id.button_delete);
		
		btnDelete.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				String fname=editTextDelete.getText().toString();
    			DBHelper dbHelper=new DBHelper(getApplicationContext());
				boolean isDelete=dbHelper.deleteDate(fname);
				if(isDelete)
				{
					Toast.makeText(getApplicationContext(), "Recrd is deleted",2000).show();
				}
				else
				{
					Toast.makeText(getApplicationContext(), "Some Problem to delete Record",2000).show();
				}
			}
		});
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.delete, menu);
		return true;
	}

}
