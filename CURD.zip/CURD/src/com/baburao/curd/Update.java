package com.baburao.curd;

import database.DBHelper;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Update extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_update);
		
		//getting the Id of Control
				final EditText editTextFname=(EditText)findViewById(R.id.editText1);
				final EditText editTextlname=(EditText)findViewById(R.id.editText2);
				Button  btnUpdate=(Button)findViewById(R.id.button_update_data);
				
				
				//setting the onClick listener on insert button
				btnUpdate.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View arg0) {
						// TODO Auto-generated method stub
						
						//Creating the object of DBHelper
						DBHelper dbHelper=new DBHelper(getApplicationContext());
						
						//getting the values of EditText
					    boolean isInsert=dbHelper.updateData(editTextFname.getText().toString(),editTextlname.getText().toString());
					    if(isInsert==true)
					    {
					    	Toast.makeText(getApplicationContext(), "Record Is Updated Successfully.",Toast.LENGTH_LONG).show();
					    }
					    else
					    {
					    	Toast.makeText(getApplicationContext(), "Some Problem To Update Record.",Toast.LENGTH_LONG).show();
					    }
					   
					 
					}
					
				});
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.update, menu);
		return true;
	}

}
