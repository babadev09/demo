package com.baburao.curd;

import database.DBHelper;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Insert extends Activity {
     EditText editTextFname;
	 EditText editTextlname;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_insert);
		
		//getting the Id of Control
	     editTextFname=(EditText)findViewById(R.id.editText_fname);
		 editTextlname=(EditText)findViewById(R.id.editText_lname);
		 Button  btnInsert=(Button)findViewById(R.id.button_insert_data);
		
		
		//setting the onClick listener on insert button
		btnInsert.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				//Creating the object of DBHelper
				DBHelper dbHelper=new DBHelper(getApplicationContext());
				
				//getting the values of EditText
				
				String fname=editTextFname.getText().toString();
				String lname=editTextlname.getText().toString();
			    boolean isInsert=dbHelper.insetData(fname,lname);
			    if(isInsert==true)
			    {
			    	Toast.makeText(getApplicationContext(), "Record Is Inserted Successfully.",Toast.LENGTH_LONG).show();
			    }
			    else
			    {
			    	Toast.makeText(getApplicationContext(), "Some Problem To Insert Record.",Toast.LENGTH_LONG).show();
			    }
			   
			 
			}
			
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.insert, menu);
		return true;
	}

}
