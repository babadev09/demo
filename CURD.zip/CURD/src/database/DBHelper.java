package database;

import java.util.ArrayList;
import java.util.Currency;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper  extends SQLiteOpenHelper {
	
	public static String DATABASE_NAME="db.db";
	

	public DBHelper(Context context) {
		super(context, DATABASE_NAME, null, 1);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		db.execSQL("create table curd_table1"+"(id Integer primary key,"+"fname text,"+"lname text)");              
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		db.execSQL("DROP TABLE IF EXISTS curd_table1");
		onCreate(db);
	}
	
	
	public boolean insetData(String fname,String lname)
	{
		SQLiteDatabase db=this.getWritableDatabase();
		ContentValues contentValues=new ContentValues();
		
		contentValues.put("fname", fname);
		contentValues.put("lname", lname);
		
		db.insert("curd_table1", null,contentValues);
		db.close();
		return true;
	}
	
	public boolean updateData(String fname,String lname)
	{
		  SQLiteDatabase db=this.getWritableDatabase();
		   db.execSQL("update curd_table1 set lname='"+lname+"' where fname='"+fname+"' ");
		   db.close();
		   return true;
	}
	
	public boolean deleteDate(String fname)
	{
		 SQLiteDatabase db=this.getWritableDatabase();
		 db.execSQL("delete  from curd_table1 where fname='"+fname+"' ");
		 db.close();
		 return true;
	}
	
	public List<String> selectAll()
	{
		List<String> list=new ArrayList<String>();
		String selectQuery="select * from curd_table1";
		
		SQLiteDatabase db=this.getReadableDatabase();
	     Cursor cursor=db.rawQuery(selectQuery, null);
	     if(cursor.moveToFirst())
	      do
	      {
	    	  String id=cursor.getString(0);
	    	  String fname=cursor.getString(1);
	    	  String lname=cursor.getString(2);
	    	  list.add(id+""+fname+"           "+lname);
	     }while(cursor.moveToNext());
	     
	     //close the cursor
	     cursor.close();
	     //close the db
	     db.close();
	     
	     //returning list
	     return list;
    }

}
